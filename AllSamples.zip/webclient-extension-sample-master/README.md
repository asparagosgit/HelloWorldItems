# WELCOME

This is your first extension for SAP Business One Web Client.

### Happy Development!

#### 1. Deploy to node

Please get sample code from this repositoty<br>
* Please run `deploy_addon1.ps1` or `deploy_addon2.ps1` for Windows<br>
* Please run `deploy_addon1.sh` or `deploy_addon2.sh` for Mac<br>
You can check http://YourIP:8888/package.json and copy this URL<br>

#### 2. Register to Extension Manager

Please click the Register button and paste the URL you copied from previous step<br>

#### 3. Run Extension in Web Client

* For addon1, please check new tile `fiori-rate` under Add-Ons.<br>
* For addon2, please check new tab for Items detail view.<br>
