#!/bin/bash
echo "Packaging extension"
rm -r webapp
mkdir webapp
cd "src/addon1"
zip -r ../../webapp/package.zip ./*
cp ./package.json ../../webapp/package.json

echo "Starting extension"
cd ../..
npm install
node http_proxy_server.js
