#powershell
Write-Output "Packaging extension"
Remove-Item webapp -Recurse -ErrorAction Ignore -Force
New-Item webapp -itemtype Directory
Set-Location .\src\addon2
Compress-Archive .\* -DestinationPath ..\..\webapp\package.zip
Copy-Item -Path .\package.json -Destination ..\..\webapp\package.json

Write-Output "Starting extension"
Set-Location ..\..
npm install
node http_proxy_server.js