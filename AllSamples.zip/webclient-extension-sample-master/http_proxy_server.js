var express = require('express')
var request = require('request');
var cors = require('cors');

var app = express();
app.use(cors({origin: '*'}));
app.use(express.static('webapp', {'dotfiles':'allow'}));

debugger;

var port = process.env.PORT || 8888
app.listen(port);
console.log("listen port : " + port);