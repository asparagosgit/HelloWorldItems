#!/bin/bash

#this script add currency code and set exchange rate
#set -x

SL_URL="http://10.193.84.13:50001/b1s/v1"
CompanyDB="US_I041967_3665_11_19"
Today=$(date '+%Y-%m-%d')
echo "Login company ${CompanyDB}"
curl  -b cookies.txt -c cookies.txt \
-X POST \
  $SL_URL/Login \
  -H 'Postman-Token: 813de3ba-7030-4c68-80b4-065963be252a,123a75bd-b9a3-4880-b513-da14d7ca5162' \
  -H 'cache-control: no-cache' \
  -d "{
    \"CompanyDB\": \"${CompanyDB}\",
    \"UserName\": \"manager\",
    \"Password\": \"manager\"
}"
array_Objs=('EUR' 'CNY' 'GBP' 'ILS' )
array_Desc=('CN Yuan' 'U.K. Pound Sterling' 'Israeli New Sheqel')

for f in ${array_Objs[@]:1}
do
echo "Add currency ${f}"
curl -b cookies.txt -c cookies.txt \
-X POST \
  $SL_URL/Currencies \
  -H 'Accept: */*' \
  -d "{
    \"Code\": \"${f}\",
    \"Name\": \"${f}\",
    \"DocumentsCode\": \"${f}\",
    \"InternationalDescription\": \"${f}\"
}"
done 
for currency in ${array_Objs[*]}
do
echo "Set rate for currency ${currency} on ${Today}"
curl -b cookies.txt -c cookies.txt \
-X POST \
  $SL_URL/SBOBobService_SetCurrencyRate \
  -H 'Accept: */*' \
  -d "{
    \"Currency\": \"${currency}\",
    \"RateDate\": \"${Today}\",
    \"Rate\": \"2\"
}"
done

