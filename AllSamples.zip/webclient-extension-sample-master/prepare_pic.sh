#!/bin/bash

#this script add path for item picture
#set -x

apt-get update
apt-get install cifs-utils
mkdir -m 777 /mnt/share
mount -t cifs //10.58.114.30/ThinClient/image /mnt/share -o username=i041967,ro
