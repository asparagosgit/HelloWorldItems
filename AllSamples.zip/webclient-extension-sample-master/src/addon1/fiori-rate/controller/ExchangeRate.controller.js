sap.ui.define(["uiext/package-rate/fiori-rate/controller/BaseController", "sap/ui/model/json/JSONModel", "sap/ui/core/routing/History",
    "uiext/package-rate/fiori-rate/model/formatter", "sap/ui/model/Filter", "sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, History, formatter, Filter, FilterOperator) {
    "use strict";

    return BaseController.extend("uiext.package-rate.fiori-rate.controller.ExchangeRate", {

        formatter: formatter,
        currentIndex: undefined,

        /**
         * Called when the exchangerate controller is instantiated.
         * @public
         */
        onInit: function () {
            var oViewModel, oToday = this.byId("today");
            // keeps the search state
            this._aTableSearchState = [];

            // Model used to manipulate control states
            oViewModel = new JSONModel({
                exchangerateTableTitle: this.getResourceBundle().getText("exchangerateTableTitle"),
                tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
                tableBusyDelay: 0
            });
            this.setModel(oViewModel, "exchangerateView");

            var td = this.getCurrentDate();
            oToday.setText(td);

            this.preloadModel();
            this.onCheckRate();

        },

        /**
         * Get today's date
         * @private
         */
        getCurrentDate: function () {
            var now = new Date();
            var y = now.getFullYear();
            var m = now.getMonth() + 1;
            var d = now.getDate();
            m = m < 10 ? "0" + m : m;
            d = d < 10 ? "0" + d : d;
            var today = y.toString() + "-" + m.toString() + "-" + d.toString();
            return today;
        },

        /**
         * Get all currency codes needed
         * @private
         */
        getCurrencies: function () {
            var currencies = [];

            var eur = {
                CurrencyCode: "EUR",
                "Name": "EURO",
                "Rate": "",
                "latestExchangeRate": ""
            };
            var gbp = {
                CurrencyCode: "GBP",
                "Name": "U.K. Pound Sterling",
                "Rate": "",
                "latestExchangeRate": ""
            };
            var ils = {
                CurrencyCode: "ILS",
                "Name": "Israeli New Sheqel",
                "Rate": "",
                "latestExchangeRate": ""
            };
            var cny = {
                CurrencyCode: "CNY",
                "Name": "Chinese Yuan",
                "Rate": "",
                "latestExchangeRate": ""
            };
            currencies.push(eur);
            currencies.push(gbp);
            currencies.push(ils);
            currencies.push(cny);
            return currencies;
        },

        /**
         * Get exchange rate one by one
         * @private
         */
        getCurlatest: function (slCallurl, paras, apiurl) {
            var date = this.getCurrentDate();
            var oTable = this.byId("table");
            var that = this;

            if (this.currentIndex >= paras.length) {
                //Get exchange rate from 3rd party service if url provided
                if (apiurl !== undefined) {
                    $.ajax({
                        method: 'get',
                        url: apiurl,
                        contentType: "text/plain",
                        async: false,
                        cache: true,
                        success: function (result) {
                            for (var x in paras) {
                                var code = paras[x].CurrencyCode.toLocaleLowerCase();
                                paras[x].latestExchangeRate = result[code].rate;

                            }
                        },
                        error: function () {
                            sap.m.MessageToast.show(this.getResourceBundle().getText("errorText") + apiurl);
                            that.currentIndex++;
                            that.getCurlatest(slCallurl, paras, apiurl);

                        }
                    });
                }

                var result = JSON.stringify(paras);
                var x = new JSONModel(JSON.parse(result));
                oTable.setModel(x);

                return;
            }
            var curCode = paras[this.currentIndex].CurrencyCode;
            var data = {
                "Currency": curCode,
                Date: date
            };
            //Get exchange rate from Web Client via service layer
            $.ajax({
                method: 'post',
                url: slCallurl,
                contentType: "text/plain",
                async: false,
                cache: true,
                data: JSON.stringify(data),
                success: function (json) {
                    var rate = json;
                    paras[that.currentIndex].Rate = rate;
                    that.currentIndex++;
                    that.getCurlatest(slCallurl, paras, apiurl);
                },
                error: function () {
                    sap.m.MessageToast.show(this.getResourceBundle().getText("errorText") + slCallurl);
                    paras[that.currentIndex].Rate = 1;
                    that.currentIndex++;
                    that.getCurlatest(slCallurl, paras, apiurl);
                }
            });
        },

        /**
         * Set exchange rate for selected currencies
         * @private
         */
        setCurlatest: function (paras, selected) {
            var date = this.getCurrentDate();
            var oTable = this.byId("table");
            var that = this;
            if (this.currentIndex >= paras.length) {
                var result = JSON.stringify(paras);
                var x = new JSONModel(JSON.parse(result));
                oTable.setModel(x);
                sap.m.MessageToast.show(this.getResourceBundle().getText("successText"));
                return;
            }
            var curCode = paras[this.currentIndex].CurrencyCode;
            var curRate = paras[this.currentIndex].latestExchangeRate;
            var slCallurl = "/svcl/b1s/v1/SBOBobService_SetCurrencyRate";
            if (selected.includes(this.currentIndex)) {
                var getdata = {
                    "Currency": curCode,
                    "RateDate": date,
                    "Rate": curRate
                };
                //Set exchange rate to Web Client via service layer
                $.ajax({
                    method: 'post',
                    url: slCallurl,
                    contentType: "text/plain",
                    async: false,
                    cache: true,
                    data: JSON.stringify(getdata),
                    success: function () {
                        paras[that.currentIndex].Rate = paras[that.currentIndex].latestExchangeRate;
                        that.currentIndex++;
                        that.setCurlatest(paras, selected);
                    },
                    error: function () {
                        sap.m.MessageToast.show(this.getResourceBundle().getText("errorText") + slCallurl);
                        that.currentIndex++;
                        that.setCurlatest(paras, selected);
                    }
                });
            } else {
                var setdata = {
                    "Currency": curCode,
                    Date: date
                };
                slCallurl = "/svcl/b1s/v1/SBOBobService_GetCurrencyRate";
                //Get exchange rate from Web Client via service layer
                $.ajax({
                    method: 'post',
                    url: slCallurl,
                    contentType: "text/plain",
                    async: false,
                    cache: true,
                    data: JSON.stringify(setdata),
                    success: function (json) {
                        var rate = json;
                        paras[that.currentIndex].Rate = rate;
                        that.currentIndex++;
                        that.setCurlatest(paras, selected);
                    },
                    error: function () {
                        sap.m.MessageToast.show(this.getResourceBundle().getText("errorText") + slCallurl);
                        paras[that.currentIndex].Rate = 1;
                        that.currentIndex++;
                        that.setCurlatest(paras, selected);
                    }
                });
            }
        },

        preloadModel: function () {
            var oTable = this.byId("table");
            var result = JSON.stringify(this.getCurrencies());
            var x = new JSONModel(JSON.parse(result));
            oTable.setModel(x);

        },

        /**
         * Save exchange rate to Web Client via service layer
         * @private
         */
        onPressUpdateSL: function () {
            var oTable = this.byId("table");
            var selectedCurrencies = [];

            var currencies = this.getCurrencies();
            for (var i = 0; i < oTable.getSelectedItems().length; i++) {
                var item = oTable.getSelectedItems()[i];
                var index = oTable.indexOfItem(item);
                selectedCurrencies.push(index);
            }
            //Get exchange rate from 3rd party service
            var apiurl = "https://www.floatrates.com/daily/usd.json";
            $.ajax({
                method: 'get',
                url: apiurl,
                contentType: "text/plain",
                async: false,
                cache: true,
                success: function (result) {
                    for (var x in currencies) {
                        var code = currencies[x].CurrencyCode.toLocaleLowerCase();
                        currencies[x].latestExchangeRate = result[code].rate;

                    }
                },
                error: function () {
                    sap.m.MessageToast.show(this.getResourceBundle().getText("errorText") + apiurl);
                }
            });
            this.currentIndex = 0;
            this.setCurlatest(currencies, selectedCurrencies);
        },

        /**
         * Initially load exchange rate from Web Client via service layer and 3rd party service
         * @private
         */
        onCheckRate: function () {
            this.preloadModel();
            var oViewModel,
                arrow = this.byId("Arrow"),
                latestRateColumn = this.byId("LatestRateColumn");

            // keeps the search state
            this._aTableSearchState = [];

            // Model used to manipulate control states
            oViewModel = new JSONModel({
                exchangerateTableTitle: this.getResourceBundle().getText("exchangerateTableTitle"),
                tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
                tableBusyDelay: 0
            });
            this.setModel(oViewModel, "exchangerateView");

            arrow.setVisible(true);
            latestRateColumn.setVisible(true);

            var url = "/svcl/b1s/v1/SBOBobService_GetCurrencyRate";
            var currencies = this.getCurrencies();
            var apiurl = "https://www.floatrates.com/daily/usd.json";
            this.currentIndex = 0;
            this.getCurlatest(url, currencies, apiurl);

        }
    });
});