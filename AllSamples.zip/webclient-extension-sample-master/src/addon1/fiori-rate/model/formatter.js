sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 4 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 4 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(4);
		}

	};

});