define(function () {

	// New button
	const BTN_HELLO_WORLD = "uuid_hello_world";

	// Event names
	const onAfterButtonClickBtnHelloWorld = `on${BTN_HELLO_WORLD}AfterButtonClick`;

	return {
		[onAfterButtonClickBtnHelloWorld]: async function (oInst) {
			oInst.showMessageBox("Success", `Hello World`, [{
				label: "OK",
				key: "OK"
			}]);
		}
	};

});